package es.uam.padsof.objetoreproducible;

public class pruebaListas {
	public static void main(String[] args) {
		
	}
}
